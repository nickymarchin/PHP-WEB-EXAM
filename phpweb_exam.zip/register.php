<?php

require_once "common.php";

$userHttpHandler->registerUser($userService, $_POST);