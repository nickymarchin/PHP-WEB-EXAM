<?php

require_once "common.php";

$userHttpHandler->login($userService, $_POST);