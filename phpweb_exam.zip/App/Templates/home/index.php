<h1>Hello Guest</h1>

If you have an account, you can <a href="login.php">login</a>
to our system. Otherwise, just <a href="register.php">register</a>