<?php /** @var \App\Data\UserDTO $data */ ?>

<h1>Hello, "<?= $data; ?>"</h1>

<a href="add_book.php"> Add new book </a> | <a href="logout.php">Logout</a> <br /><br />

<a href="my_books.php"> My Books </a> <br /><br />

<a href="all_books.php"> All Books </a>


